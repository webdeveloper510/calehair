<!-- Start Mobile Menu Icon -->
			<div class="mobile-header">
				<a class="responsive-menu-button" href="#">
					<em class="fa fa-bars"></em> <?php _e("Menu", "loc_canon"); ?>
				</a>
			</div>
