                                    <!-- WORDPRESS MENU: SECONDARY MENU -->
                                    <?php wp_nav_menu(array( 
                                        'theme_location'    => 'secondary_menu',
                                        'menu_id'           => 'secondary_menu',
                                        'menu_class'        => 'secondary_menu nav',
                                        'container'         => 'nav',
                                        'container_class'   => 'secondary_menu_container',
                                        'container_id'      => 'nav-wrap2',
                                        'show_home'         => '1'
                                        ));
                                    ?>
