    	    	<ul class="menuHideBtn">
    	    		<li><a class="closebtn" href="#"><i class="fa fa-close"></i></a></li>
    	    	</ul>
