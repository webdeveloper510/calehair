<?php // $canon_options_frame = get_option('canon_options_frame'); ?>


		<div class="outter-wrapper pre-footer breadcrumb-wrapper feature">		
			<div class="wrapper">

				<?php echo mb_get_breadcrumbs(); ?>

			</div>
		</div>	