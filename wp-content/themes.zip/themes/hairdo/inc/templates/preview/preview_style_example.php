<!-- PREVIEW_STYLE_EXAMPLE -->

<style type="text/css" scoped>

	.preview_debug {
		color: red;	
	}

	#pb_block-1 {
		background-color: red;	
	}
	
</style>

