<?php /* Template Name: Blog */ ?>

<?php get_header(); ?>

    <?php get_template_part('inc/templates/template_archive'); ?>
  
<?php get_footer(); ?>
