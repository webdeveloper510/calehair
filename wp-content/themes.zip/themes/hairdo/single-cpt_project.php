<?php get_header(); ?>

<?php get_template_part('inc/templates/template_single_project'); ?>
    	
<?php get_footer(); ?>